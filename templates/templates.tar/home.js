function subscribe() {
    location.href = "subscribe.html"
  }

  function login() {
    location.href = "login.html"
  }

  function menu() {
    
  }