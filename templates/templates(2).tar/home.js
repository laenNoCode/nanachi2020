function subscribe() {
    location.href = "subscribe.html"
  }

  function login() {
    location.href = "login.html"
  }

  function menu() {
    
  }

  function logout(){
    location.href = "home.html"
  }

  function profil(){
    location.href = "profil.html"
  }

  function profilEdit(){
    location.href = "profil-edit.html"
  }

  function home(){
    location.href = "home.html"
  }

  function homeIn(){
    location.href = "home-in.html"
  }